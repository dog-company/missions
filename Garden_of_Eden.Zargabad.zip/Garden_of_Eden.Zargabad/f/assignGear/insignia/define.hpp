class AAF_A1_Badge
{
	displayName = "AAF A1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_A1.paa";
};
class AAF_A2_Badge
{
	displayName = "AAF A2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_A2.paa";
};
class AAF_A3_Badge
{
	displayName = "AAF A3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_A3.paa";
};
class AAF_ASL_Badge
{
	displayName = "AAF ASL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_ASL.paa";
};
class AAF_B1_Badge
{
	displayName = "AAF B1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_B1.paa";
};
class AAF_B2_Badge
{
	displayName = "AAF B2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_B2.paa";
};
class AAF_B3_Badge
{
	displayName = "AAF B3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_B3.paa";
};
class AAF_BSL_Badge
{
	displayName = "AAF BSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_BSL.paa";
};
class AAF_C1_Badge
{
	displayName = "AAF C1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_C1.paa";
};
class AAF_C2_Badge
{
	displayName = "AAF C2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_C2.paa";
};
class AAF_C3_Badge
{
	displayName = "AAF C3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_C3.paa";
};
class AAF_CO_Badge
{
	displayName = "AAF CO";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_CO.paa";
};
class AAF_CSL_Badge
{
	displayName = "AAF CSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_CSL.paa";
};
class AAF_DC_Badge
{
	displayName = "AAF DC";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_DC.paa";
};
class AAF_Medic_Badge
{
	displayName = "AAF Medic";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_Medic.paa";
};
class AAF_J1_Badge
{
	displayName = "AAF J1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_J1.paa";
};
class AAF_J2_Badge
{
	displayName = "AAF J2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_J2.paa";
};
class AAF_J3_Badge
{
	displayName = "AAF J3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_J3.paa";
};
class AAF_JSL_Badge
{
	displayName = "AAF JSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\AAF_JSL.paa";
};
class CSAT_A1_Badge
{
	displayName = "CSAT A1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_A1.paa";
};
class CSAT_A2_Badge
{
	displayName = "CSAT A2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_A2.paa";
};
class CSAT_A3_Badge
{
	displayName = "CSAT A3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_A3.paa";
};
class CSAT_ASL_Badge
{
	displayName = "CSAT ASL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_ASL.paa";
};
class CSAT_B1_Badge
{
	displayName = "CSAT B1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_B1.paa";
};
class CSAT_B2_Badge
{
	displayName = "CSAT B2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_B2.paa";
};
class CSAT_B3_Badge
{
	displayName = "CSAT B3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_B3.paa";
};
class CSAT_BSL_Badge
{
	displayName = "CSAT BSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_BSL.paa";
};
class CSAT_C1_Badge
{
	displayName = "CSAT C1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_C1.paa";
};
class CSAT_C2_Badge
{
	displayName = "CSAT C2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_C2.paa";
};
class CSAT_C3_Badge
{
	displayName = "CSAT C3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_C3.paa";
};
class CSAT_CO_Badge
{
	displayName = "CSAT CO";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_CO.paa";
};
class CSAT_CSL_Badge
{
	displayName = "CSAT CSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_CSL.paa";
};
class CSAT_DC_Badge
{
	displayName = "CSAT DC";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_DC.paa";
};
class CSAT_Medic_Badge
{
	displayName = "CSAT Medic";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Medic.paa";
};
class CSAT_J1_Badge
{
	displayName = "CSAT J1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_J1.paa";
};
class CSAT_J2_Badge
{
	displayName = "CSAT J2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_J2.paa";
};
class CSAT_J3_Badge
{
	displayName = "CSAT J3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_J3.paa";
};
class CSAT_JSL_Badge
{
	displayName = "CSAT JSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_JSL.paa";
};
class CSAT_Urban_J1_Badge
{
	displayName = "CSAT Urban J1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_J1.paa";
};
class CSAT_Urban_J2_Badge
{
	displayName = "CSAT Urban J2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_J2.paa";
};
class CSAT_Urban_J3_Badge
{
	displayName = "CSAT Urban J3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_J3.paa";
};
class CSAT_Urban_JSL_Badge
{
	displayName = "CSAT Urban JSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_JSL.paa";
};
class CSAT_Urban_A1_Badge
{
	displayName = "CSAT Urban A1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_A1.paa";
};
class CSAT_Urban_A2_Badge
{
	displayName = "CSAT Urban A2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_A2.paa";
};
class CSAT_Urban_A3_Badge
{
	displayName = "CSAT Urban A3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_A3.paa";
};
class CSAT_Urban_ASL_Badge
{
	displayName = "CSAT Urban ASL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_ASL.paa";
};
class CSAT_Urban_B1_Badge
{
	displayName = "CSAT Urban B1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_B1.paa";
};
class CSAT_Urban_B2_Badge
{
	displayName = "CSAT Urban B2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_B2.paa";
};
class CSAT_Urban_B3_Badge
{
	displayName = "CSAT Urban B3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_B3.paa";
};
class CSAT_Urban_BSL_Badge
{
	displayName = "CSAT Urban BSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_BSL.paa";
};
class CSAT_Urban_C1_Badge
{
	displayName = "CSAT Urban C1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_C1.paa";
};
class CSAT_Urban_C2_Badge
{
	displayName = "CSAT Urban C2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_C2.paa";
};
class CSAT_Urban_C3_Badge
{
	displayName = "CSAT Urban C3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_C3.paa";
};
class CSAT_Urban_CO_Badge
{
	displayName = "CSAT Urban CO";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_CO.paa";
};
class CSAT_Urban_CSL_Badge
{
	displayName = "CSAT Urban CSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_CSL.paa";
};
class CSAT_Urban_DC_Badge
{
	displayName = "CSAT Urban DC";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_DC.paa";
};
class CSAT_Urban_Medic_Badge
{
	displayName = "CSAT Urban Medic";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\CSAT_Urban_Medic.paa";
};
class NATO_A1_Badge
{
	displayName = "NATO A1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_A1.paa";
};
class NATO_A2_Badge
{
	displayName = "NATO A2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_A2.paa";
};
class NATO_A3_Badge
{
	displayName = "NATO A3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_A3.paa";
};
class NATO_ASL_Badge
{
	displayName = "NATO ASL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_ASL.paa";
};
class NATO_B1_Badge
{
	displayName = "NATO B1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_B1.paa";
};
class NATO_B2_Badge
{
	displayName = "NATO B2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_B2.paa";
};
class NATO_B3_Badge
{
	displayName = "NATO B3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_B3.paa";
};
class NATO_BSL_Badge
{
	displayName = "NATO BSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_BSL.paa";
};
class NATO_C1_Badge
{
	displayName = "NATO C1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_C1.paa";
};
class NATO_C2_Badge
{
	displayName = "NATO C2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_C2.paa";
};
class NATO_C3_Badge
{
	displayName = "NATO C3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_C3.paa";
};
class NATO_CO_Badge
{
	displayName = "NATO CO";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_CO.paa";
};
class NATO_CSL_Badge
{
	displayName = "NATO CSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_CSL.paa";
};
class NATO_DC_Badge
{
	displayName = "NATO DC";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_DC.paa";
};
class NATO_Medic_Badge
{
	displayName = "NATO Medic";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_Medic.paa";
};
class NATO_J1_Badge
{
	displayName = "NATO J1";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_J1.paa";
};
class NATO_J2_Badge
{
	displayName = "NATO J2";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_J2.paa";
};
class NATO_J3_Badge
{
	displayName = "NATO J3";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_J3.paa";
};
class NATO_JSL_Badge
{
	displayName = "NATO JSL";
	author = "F3 Framework";
	texture = "f\assignGear\insignia\NATO_JSL.paa";
};
