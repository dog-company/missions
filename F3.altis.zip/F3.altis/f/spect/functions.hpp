class fspectator
{
	file = "f\spect";
	class CamInit{};
	class OnUnload{};
	class DrawTags{};
	class EventHandler{};
	class FreeCam{};
	class GetPlayers{};
	class ReloadModes{};
	class UpdateValues{};
	class HandleCamera{};
	class ToggleGUI{};
	class OnMapClick{};
	class DrawMarkers{};
	class ForceExit{};
	class HandleMenu{};
	class showMenu{};
};